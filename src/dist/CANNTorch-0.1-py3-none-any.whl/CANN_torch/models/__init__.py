# src/CANN_torch/models/__init__.py

from .CNN import CNN
from .Perceptron import Perceptron
from .potential_zoo import *
