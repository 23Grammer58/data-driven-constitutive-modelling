from setuptools import setup, find_packages

setup(
    name='CANNTorch',
    version='0.1',
    packages=find_packages(),
    # install_requires=[
    #     # List your dependencies here
    #     'torch',
    #     'numpy',
    #     'matplotlib',
    # ],
    entry_points={
        'console_scripts': [
            # If you have command-line scripts, define them here
        ],
    },
    author='Daniil Dits',
    author_email='your.email@example.com',
    description='A package for neural network models and utilities',
    # long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/yourusername/CANNTorch',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)
